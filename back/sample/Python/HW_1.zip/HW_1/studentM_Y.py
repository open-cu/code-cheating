sentence = "This is just a test"
target = "just"

idx = sentence.find(target)

print(f"The word '{target}'' starts at index {idx} in '{sentence}'")


def sum(a, b):
    return a + b


print(sum(1, 2))

n1 = 10
n2 = 100

maximum = max(n1, n2)

print(f"The maximum number is {maximum}")
