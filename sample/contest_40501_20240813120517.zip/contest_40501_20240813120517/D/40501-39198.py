a, b = int(input()), int(input())
print(((2 * a) // (a + b) * a + (2 * b) // (a + b) * b) // ((2 * a) // (a + b) + (2 * b) // (a + b)))