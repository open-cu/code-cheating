a = int(input())
b = int(input())
print((((a // b) * a) + ((b // a) * b)) // ((a // b) + (b // a)))
