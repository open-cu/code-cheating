a = int(input())
b = int(input())

if a // b == 0:
    print(b)

elif b // a == 0:
    print(a)

else:
    print(a)
