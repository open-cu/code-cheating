a = int(input())
b = int(input())

print(int(((a // b) * a + (b // a) * b) / ((a // b) + (b // a))))
