a = int(input())
b = int(input())
c = (a // b * a + b // a * b) // (a // b + b // a)
print(c)
