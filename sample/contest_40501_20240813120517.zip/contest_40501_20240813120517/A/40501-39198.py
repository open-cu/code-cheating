s = input()
print('NO' if s.isdigit() or s.isalpha() else 'YES')