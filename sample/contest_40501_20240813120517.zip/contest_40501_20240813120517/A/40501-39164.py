s = input()
if 145 <= ord(s[0]) + ord(s[1]) <= 179:
    print('YES')
else:
    print('NO')