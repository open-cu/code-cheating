s = input()
print('NO' if s.isalpha() or s.isnumeric() else 'YES')