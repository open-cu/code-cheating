n = int(input())
k = 0
for i in range(2, int(n**0.5) + 1):
    if n % i == 0:
        k += 1
if k == 0:
    print('prime')
else:
    print('composite')