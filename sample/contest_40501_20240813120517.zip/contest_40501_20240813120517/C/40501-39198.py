a, b = int(input()), int(input())
print((b % a) * (a % b) + 1)