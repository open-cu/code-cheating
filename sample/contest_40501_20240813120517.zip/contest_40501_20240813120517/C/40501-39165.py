a = int(input())
b = int(input())
print(1 if (a % b == 0 or b % a == 0) else 0)
