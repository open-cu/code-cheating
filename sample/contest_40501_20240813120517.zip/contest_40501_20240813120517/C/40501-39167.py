a = int(input())
b = int(input())
print(((a % b) * (b % a)) + 1)