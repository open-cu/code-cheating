def solution():
    a = int(input())
    b = int(input())

    print(1 + (a % b) * (b % a))


solution()
