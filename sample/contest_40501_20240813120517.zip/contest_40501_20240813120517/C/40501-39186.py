n1 = int(input())
n2 = int(input())
print((n1 % n2) * (n2 % n1) + 1)
