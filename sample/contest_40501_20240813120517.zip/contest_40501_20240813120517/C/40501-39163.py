a = int(input())
b = int(input())
c = (a % b) * (b % a) + 1
print(c)
