num1 = int(input(''))
num2 = int(input(''))

print(1 + (num1 % num2) * (num2 % num1))
