n1 = int(input())
n2 = int(input())

a = n1 % n2
b = n2 % n1
print(a * b + 1)
